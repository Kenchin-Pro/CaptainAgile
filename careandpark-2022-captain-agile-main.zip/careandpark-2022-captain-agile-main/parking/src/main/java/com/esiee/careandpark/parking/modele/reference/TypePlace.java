package com.esiee.careandpark.parking.modele.reference;

public enum TypePlace {
	NOMINALE, HANDICAPE, DEUX_ROUES, BUS;
}
