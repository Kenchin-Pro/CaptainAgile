package com.esiee.careandpark.parking.modele.reference;

public enum EtatPlace {
	Libre, Occupe;
}
